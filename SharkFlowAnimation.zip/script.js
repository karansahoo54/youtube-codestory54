
let mouse = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
let fps = 30;
let parts = [];
let element = document.getElementById("shark-container");

function init() {
  document.addEventListener("mousemove", mousemove);
  createShark();
  setInterval(loop, 1000 / fps);
}

function mousemove(e) {
  mouse = { x: e.clientX, y: e.clientY };
}

function createShark() {
  let shark = document.createElement("div");
  shark.classList.add("shark");
  shark.style.left = "0px";
  shark.style.top = "50%";
  element.appendChild(shark);
  parts.push({ el: shark, z_delay: 0 });
}

function loop() {
  for (let i = 0; i < parts.length; i++) {
    let part = parts[i];
    part.el.style.left = mouse.x - 50 + "px";
    part.el.style.top = mouse.y - 30 + "px";
  }
}

init();
