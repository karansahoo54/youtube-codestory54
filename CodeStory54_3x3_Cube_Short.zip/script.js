const squares = document.querySelectorAll('.square');
let index = 0;
setInterval(() => {
  squares.forEach(sq => sq.classList.remove('active'));
  squares[index].classList.add('active');
  index = (index + 1) % squares.length;
}, 200);